package com.markaz.alothman;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.Intent;
import android.net.Uri;
import android.graphics.Typeface;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import org.json.JSONArray;
import org.json.JSONObject;
import java.net.URLEncoder;
import java.util.ArrayList;

public class MainActivity extends Activity {
    private final String waNumber = "963953904215";
    private final ArrayList<Product> products = new ArrayList<>();
    private LinearLayout root, list;
    private EditText customerName, customerPhone, customerAddress;
    private TextView totalView;
    private int total = 0;

    static class Product {
        String name, description;
        int price;
        Product(String n, String d, int p) { name=n; description=d; price=p; }
    }

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        loadProducts();
        showStore();
    }

    private int dp(int x) { return (int)(x * getResources().getDisplayMetrics().density); }
    private TextView text(String s, int size, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(0xFF18212F);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        t.setGravity(Gravity.RIGHT);
        return t;
    }
    private void pad(View v) { v.setPadding(dp(14),dp(10),dp(14),dp(10)); }
    private LinearLayout column() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setLayoutDirection(View.LAYOUT_DIRECTION_RTL);
        return l;
    }
    private Button button(String label) {
        Button b = new Button(this); b.setText(label); return b;
    }
    private void startPage(String subtitle) {
        ScrollView scroll = new ScrollView(this);
        root = column(); root.setBackgroundColor(0xFFF5F7FB); pad(root);
        TextView title = text("مركز العثمان", 28, true);
        title.setTextColor(0xFF123B66); root.addView(title);
        TextView sub = text(subtitle, 15, false); root.addView(sub);
        View line = new View(this); line.setBackgroundColor(0xFFD8E0EA);
        root.addView(line, new LinearLayout.LayoutParams(-1, dp(1)));
        scroll.addView(root);
        setContentView(scroll);
    }
    private void loadProducts() {
        products.clear();
        String saved = getPreferences(0).getString("products", null);
        try {
            if (saved != null) {
                JSONArray a = new JSONArray(saved);
                for(int i=0;i<a.length();i++) {
                    JSONObject o=a.getJSONObject(i);
                    products.add(new Product(o.getString("name"),o.optString("description",""),o.getInt("price")));
                }
            }
        } catch(Exception ignored) {}
        if(products.isEmpty()) {
            products.add(new Product("هاتف ذكي", "أضف وصف ومواصفات الهاتف", 0));
            products.add(new Product("شاحن سريع", "إكسسوارات الهواتف", 0));
            products.add(new Product("خدمة صيانة", "فحص العطل وتحديد التكلفة", 0));
            products.add(new Product("برمجة وتحديث", "تواصل لتأكيد نوع الخدمة", 0));
        }
    }
    private void saveProducts() {
        JSONArray a=new JSONArray();
        try {
            for(Product p:products) {
                JSONObject o=new JSONObject(); o.put("name",p.name); o.put("description",p.description); o.put("price",p.price); a.put(o);
            }
            getPreferences(0).edit().putString("products",a.toString()).apply();
        } catch(Exception ignored) {}
    }
    private void showStore() {
        total=0;
        startPage("متجر الهواتف والصيانة والبرمجة");
        Button admin=button("إدارة المنتجات"); admin.setOnClickListener(v->adminLogin()); root.addView(admin);
        TextView hint=text("اختر المنتجات أو الخدمات ثم أرسل طلبك عبر واتساب. الأسعار الصفرية تجريبية ويجب تعديلها.",14,false);
        pad(hint); root.addView(hint);
        list=column(); root.addView(list);
        for(Product p:products) {
            LinearLayout card=column(); card.setBackgroundColor(0xFFFFFFFF); pad(card);
            TextView n=text(p.name,19,true); card.addView(n);
            TextView d=text(p.description,14,false); card.addView(d);
            TextView price=text(p.price>0 ? "السعر: "+p.price+" (أدخل العملة المناسبة)" : "السعر: يُحدد من المتجر",15,true); card.addView(price);
            Button add=button("إضافة إلى الطلب"); add.setOnClickListener(v->{ total+=p.price; Toast.makeText(this,"تمت إضافة "+p.name+" إلى الطلب",Toast.LENGTH_SHORT).show(); });
            card.addView(add);
            LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2); cp.setMargins(0,dp(8),0,dp(8)); root.addView(card,cp);
        }
        root.addView(text("بيانات العميل",20,true));
        customerName = new EditText(this); customerName.setSingleLine(true); customerName.setHint("الاسم الكامل"); root.addView(customerName);
        customerPhone = new EditText(this); customerPhone.setSingleLine(true); customerPhone.setHint("رقم الهاتف"); customerPhone.setInputType(3); root.addView(customerPhone);
        customerAddress = new EditText(this); customerAddress.setHint("العنوان وملاحظات الطلب"); root.addView(customerAddress);
        totalView=text("الدفع عند الاستلام",16,true); root.addView(totalView);
        Button send=button("إرسال الطلب عبر واتساب"); send.setOnClickListener(v->sendOrder()); root.addView(send);
        Button service=button("طلب صيانة أو برمجة"); service.setOnClickListener(v->{
            customerAddress.setText("طلب صيانة/برمجة: ");
            Toast.makeText(this,"أكمل بياناتك ثم أرسل الطلب عبر واتساب",Toast.LENGTH_LONG).show();
        }); root.addView(service);
    }
    private void sendOrder() {
        String name=customerName.getText().toString().trim();
        String phone=customerPhone.getText().toString().trim();
        String address=customerAddress.getText().toString().trim();
        if(name.isEmpty() || phone.isEmpty()) {
            new AlertDialog.Builder(this).setMessage("يرجى إدخال الاسم ورقم الهاتف").setPositiveButton("حسنًا",null).show(); return;
        }
        StringBuilder msg=new StringBuilder("طلب جديد — مركز العثمان%0A");
        msg.append("الاسم: ").append(name).append("%0Aالهاتف: ").append(phone).append("%0Aالعنوان/الطلب: ").append(address);
        msg.append("%0Aطريقة الدفع: عند الاستلام");
        try {
            String encoded=URLEncoder.encode(msg.toString().replace("%0A","\n"),"UTF-8");
            Intent i=new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/"+waNumber+"?text="+encoded));
            startActivity(i);
        } catch(Exception e) {
            Toast.makeText(this,"تعذر فتح واتساب. تحقق من تثبيته أو من الاتصال بالإنترنت.",Toast.LENGTH_LONG).show();
        }
    }
    private void adminLogin() {
        EditText pass=new EditText(this); pass.setHint("رمز الإدارة التجريبي: 1234"); pass.setInputType(2);
        new AlertDialog.Builder(this).setTitle("إدارة المتجر").setMessage("أدخل الرمز التجريبي").setView(pass)
          .setNegativeButton("إلغاء",null).setPositiveButton("دخول",(d,w)->{
              if("1234".equals(pass.getText().toString())) showAdmin();
              else Toast.makeText(this,"الرمز غير صحيح",Toast.LENGTH_SHORT).show();
          }).show();
    }
    private void showAdmin() {
        startPage("لوحة إدارة محلية — التعديلات على هذا الجهاز فقط");
        Button add=button("إضافة منتج"); add.setOnClickListener(v->editProduct(-1)); root.addView(add);
        for(int i=0;i<products.size();i++) {
            final int index=i;
            LinearLayout row=new LinearLayout(this); row.setOrientation(LinearLayout.HORIZONTAL);
            TextView label=text(products.get(i).name+" — "+products.get(i).price,16,true);
            row.addView(label,new LinearLayout.LayoutParams(0,-2,1));
            Button edit=button("تعديل"); edit.setOnClickListener(v->editProduct(index)); row.addView(edit);
            Button del=button("حذف"); del.setOnClickListener(v->{products.remove(index);saveProducts();showAdmin();}); row.addView(del);
            root.addView(row);
        }
        Button back=button("العودة إلى المتجر"); back.setOnClickListener(v->showStore()); root.addView(back);
    }
    private void editProduct(int index) {
        LinearLayout form=column();
        EditText name=new EditText(this); name.setHint("اسم المنتج/الخدمة");
        EditText desc=new EditText(this); desc.setHint("الوصف");
        EditText price=new EditText(this); price.setHint("السعر بالأرقام (0 إذا كان يحدد لاحقًا)"); price.setInputType(2);
        if(index>=0) { Product p=products.get(index); name.setText(p.name); desc.setText(p.description); price.setText(String.valueOf(p.price)); }
        form.addView(name); form.addView(desc); form.addView(price);
        new AlertDialog.Builder(this).setTitle(index<0?"إضافة منتج":"تعديل المنتج").setView(form)
          .setNegativeButton("إلغاء",null).setPositiveButton("حفظ",(d,w)->{
              try {
                  String n=name.getText().toString().trim(); if(n.isEmpty()) throw new Exception();
                  Product p=new Product(n,desc.getText().toString().trim(),Integer.parseInt(price.getText().toString().trim().isEmpty()?"0":price.getText().toString().trim()));
                  if(index<0) products.add(p); else products.set(index,p);
                  saveProducts(); showAdmin();
              } catch(Exception e) { Toast.makeText(this,"أدخل اسمًا صحيحًا وسعرًا رقميًا",Toast.LENGTH_LONG).show(); }
          }).show();
    }
}
